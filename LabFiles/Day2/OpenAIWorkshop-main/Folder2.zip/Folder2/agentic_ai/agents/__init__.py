"""Agent package marker to enable imports like agents.agent_framework.*."""
